# AGENTS.md

Guidelines for how AI tools may be used in this repository. See `CLAUDE.md` for the Claude-specific pointer to this file.

[TODO: personalize this in your own words — the notes below are a starting draft, not a final policy]

## What AI may do
- Generate skeleton structure (folders, placeholder files, boilerplate) that I review before committing.
- Help draft rough versions of briefs, notes, or code that I then revise.
- Assist with debugging, formatting, and research.

## What AI may not do
- Write final substantive content (briefs, analyses, reflections) without my own first draft coming first.
- Fabricate data, sources, or credentials.
- Make GitHub account or repository setting changes without my explicit confirmation.

## Logging
Any substantive AI prompt used to produce content in this repo is recorded in `prompt-log.md`.
