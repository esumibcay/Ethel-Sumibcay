# CLAUDE.md

This repository's AI usage guidelines live in [AGENTS.md](./AGENTS.md). Read that file before making changes here.
