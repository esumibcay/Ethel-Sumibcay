# Prompt Log

A running record of substantive AI prompts used in this repository — what was asked, which tool, and how the output was used or changed.

| Date | Tool | Prompt (summary) | Output used as-is? | Notes |
|---|---|---|---|---|
| | | | | |
