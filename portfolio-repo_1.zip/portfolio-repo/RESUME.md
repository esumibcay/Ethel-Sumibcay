[TODO: fill in — rough draft resume]
