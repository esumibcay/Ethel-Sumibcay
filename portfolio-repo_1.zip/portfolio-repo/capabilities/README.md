# Capabilities

One folder per capability, organized by what the work demonstrates rather than by course, term, or week.

Each capability folder contains:
- `README.md` — what the capability is and why it's here
- `spec.md` — the specification/requirements for the work
- the model file (spreadsheet, notebook, script, etc.)

No capability folders exist yet.
