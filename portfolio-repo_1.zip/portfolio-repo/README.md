# firstname-lastname

## Bio

[TODO: fill in — 3-6 sentences about yourself]

## Engagement Index

_No engagements yet. Each entry below should link to its capability folder once work begins._

| Engagement | Capability | Status | Link |
|---|---|---|---|
| _(none yet)_ | | | |
