# Briefs

Documents written **before** work begins on an engagement — problem framing, scope, and plan.
